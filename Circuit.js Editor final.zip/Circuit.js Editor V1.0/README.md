# CircuitJS-Editor
It's a JavaScript application providing an editor to simulate simple electric circuits. 

The Project has been created in ordner of a study lab by Mike Spitzmüller. 
It can be directly opened in an internet browser and integrated in other JavaScript projects.
